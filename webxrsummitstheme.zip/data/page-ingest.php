<?php
    get_header(); 
    if(@$_GET['page']=='msf'){
        $ingest_url = 'https://metaverse-standards.org/members/'
    }

?>



<?php
    get_footer(); 
?>