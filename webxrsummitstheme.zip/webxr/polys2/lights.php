<a-entity id="lighting" visible="true" static-body position="0 15 -25" rotation="0 0 0" >



<a-light id="white-d1" type="directional" color="white" intensity="5" position="0 10 -50" rotation="0 180 0" angle="90"></a-light>


<a-light id="white-d2" type="directional" color="white" intensity="5" position="-50 10 0" rotation="90 -90 0" angle="90"></a-light>


<a-light id="white-d3" type="directional" color="white" intensity="5" position="50 10 0" rotation="-90 90 0" angle="90"></a-light>


<a-light id="white-d4" type="directional" color="white" intensity="5" position="0 10 50" rotation="0 0 0" angle="90"></a-light>






<a-light id="green1" type="point" intensity="1" position="0 -120 10" rotation="0 0 0" angle="90"></a-light>
<a-light id="red1" type="point" color="#900" color="#090" intensity="1" position="-25 -80 -10" rotation="0 0 0" angle="90"></a-light>
<a-light id="blue1" type="point" color="#009" intensity="1" position="24 -80 -10" rotation="0 0 0" angle="90"></a-light>


<a-light id="yellow1" type="point" color="#Ff0" intensity="1" position="0 -140 100" rotation="0 0 0" angle="90"></a-light>

<a-light id="purple1" type="point" color="909" intensity="1" position="0 100 10" rotation="0 0 0" angle="90"></a-light>





<a-light id="yellow1" type="spot" color="#fff" intensity="15" position="0 5 30" rotation="-90 0 0" angle="90"></a-light>














           <!-- 
        <a-light type="spot" color="blue" intensity="1" position="15 -4.5 10"></a-light>


<a-light type="spot" color="blue" intensity="1" position="15 -4.5 10"></a-light>


        <a-light type="spot" color="green" intensity="1" position="0 -4.5 4"></a-light>
        <a-light type="spot" color="green" intensity="1" position="0 -4.5 10"></a-light>

        <a-light type="spot" color="blue" intensity="1" position="0 4.5 4"></a-light>
        <a-light type="spot" color="blue" intensity="1" position="0 4.5 10"></a-light>
       

        <a-light id="light-left" intensity=".6" position="-10 3 -5" rotation="0 0 0"></a-light>
        <a-light id="light-back" color="white" intensity=".5" position="-10 3 -5" rotation="0 0 0"></a-light>
       
        <a-light id="light-right" type="point" color="white" intensity=".5" position="15 4.5 -6" rotation="0 0 0">
        <a-light id="light-back" type="point" color="white" intensity=".5" position="0 3 -15" rotation="0 0 0">
        </a-light>
        <a-light id="light-front" type="point" color="white" intensity=".6" position="0 3 5" rotation="0 0 0"></a-light>


        <a-light id="L1" type="point" color="#606" intensity="1" position="0 -4.5 -4"></a-light>
        <a-light id="L2" type="point" color="#606" intensity="1" position="0 -4.5 10"></a-light>

       
        <a-light id="L4" type="point" color="#900" intensity="1" position="0 4.5 -4"></a-light>
        <a-light id="L4" type="point" color="#900" intensity="1" position="0 4.5 -10"></a-light>




        <a-light id="light-side" type="point" color="#d00" intensity="1" position="-35 10 -15" rotation="0 0 0">
        </a-light>-->
</a-entity>
