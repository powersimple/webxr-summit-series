<div class="row">

          <div class="col-sm-4 display-flex">
              
          

            <div class="profile-image"><img src="<?=$thumbnail?>" alt="<?=$post->post_title?>"></div>
            

            
            <div class="profile-logo"></div>
            <div class="profile-contact"></div>
            
          </div>
          <div class="col-sm-8 display-flex">
          
          
          <?php


          ?>
          

          </div>
          <div class="xs-col-12 col-sm-12 col-md-12 col-lg-4 tag-holder display-flex">
         
          </div>
      </div>