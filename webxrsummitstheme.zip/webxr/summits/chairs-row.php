<a-entity position="-1.5 0 0" 
rotation="0 0 0" id="chair1" gltf-model="#chair" scale="1 1 1"
visible="true"></a-entity>    

<a-entity position="-1 0 0" rotation="0 0 0" id="chair2" gltf-model="#chair" scale="1 1 1"
visible="true"></a-entity>

<a-entity position="-0.5 0 0" rotation="0 0 0" id="chair3" gltf-model="#chair" scale="1 1 1"
visible="true"></a-entity>

<a-entity position="0 0 0" rotation="0 0 0" id="chair4" gltf-model="#chair" scale="1 1 1"
    visible="true"></a-entity>

<a-entity position="0.5 0 0" rotation="0 0 0" id="chair5" gltf-model="#chair" scale="1 1 1" visible="true">
</a-entity>

<a-entity position="1 0 0" rotation="0 0 0" id="chair6" gltf-model="#chair" scale="1 1 1" visible="true">
</a-entity>

<a-entity position="1.5 0 0" rotation="0 0 0" id="chair6" gltf-model="#chair" scale="1 1 1" visible="true">
</a-entity>