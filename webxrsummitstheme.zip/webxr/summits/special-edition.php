<a-entity position="-38 163 -100" id="special-edition-content"   visible="true">


        
            
      
<a-entity position="1.123 0.737 4.65" rotation="90 180 0" id="series-logo" gltf-model="#series-model" scale="5 5 5" visible="true"></a-entity>
    
            <a-entity id="special-edition-model" class="center-obj-zone" static-body
                gltf-model="#special-edition" visible="true" scale="20 6 20" position="0 0 4.65"
                rotation="90 1.5 180"></a-entity>

                
<a-entity id="futurewei-logo-model" class="center-obj-zone" static-body
                gltf-model="#futurewei-3d-logo" visible="true" scale=".375 .2 .375" position="-2.07 0.726 4.7"
                rotation="90 3 180"></a-entity>

            <a-image material="side:front" mixin="scale-label" src="/assets/images/talent/SophiaMoshasha.jpg"
                position=".45 -.9 4.65" rotation="0 180 0"   geometry="primitive: circle; width: 2; height: 2; depth: 3" scale=".3 .3 .3" width="5" height="5">
            </a-image>
            
            <a-entity id="label-created" troika-text="value:
      Guest: Neil Trevett;color:#fff; fontSize:.8;align:left;" material="shader: standard;" position="-1.17 -1.1 4.65"
                rotation="0 180 0" scale=".2 .2 .2" visibility="true"></a-entity>

             



            </a-entity>