<a-entity id="brand-business" position="-34.9 163 -108" rotation="0 166.2 0" scale="2 2 2">
   
<a-entity id="business-summmit-square-model" class="center-obj-zone" static-body
                gltf-model="#business-summmit-square" visible="true" scale="25 8 25" position="0 0.9 0"
                rotation="90 1.5 180"></a-entity>
    <!--
            <a-entity id="business-summmit-square-model" class="center-obj-zone" static-body
                gltf-model="#business-summmit-wide" visible="true" scale="25 8 25" position="0 0.9 0"
                rotation="90 1.5 180"></a-entity> -->

                <a-entity id="futurewei-logo-model" class="center-obj-zone" static-body
                gltf-model="#futurewei-3d-logo" visible="true" scale=".375 .25 .375" position="0 2.4 0"
                rotation="90 3 180"></a-entity>
  
 <!--
                <a-entity id="WebXRsummit-FutureWei-model" class="center-obj-zone" static-body
                gltf-model="#WebXRsummit-FutureWei" visible="true" scale=".375 .55 .375" position="0 2.4 0"
                rotation="90 3 180"></a-entity>

                <a-entity id="powersimple-loci-metavrse-model" class="center-obj-zone" static-body
                gltf-model="#powersimple-loci-metavrse" visible="true" scale=".375 .55 .375" position="0 2.4 0"
                rotation="90 3 180"></a-entity>

                

            <a-entity id="powersimple-model" class="center-obj-zone" static-body
                gltf-model="#powersimple-3d-logo" visible="true" scale=".375 .375 .375" position=".25 4.7 1"
                rotation="0 120 .1"></a-entity>

            <a-entity id="futurewei-model2" class="center-obj-zone" static-body
                gltf-model="#futurewei-3d-logo2" visible="true" scale=".375 .375 .375" position=".25 2.7 1"
                rotation="0 120 .1"></a-entity>

            <a-entity id="metavrse-model" class="center-obj-zone" static-body
                gltf-model="#metavrse-3d-logo" visible="true" scale=".375 .375 .375" position=".25 3.7 1"
                rotation="0 120 .1"></a-entity>
               

                -->

            <a-image id="sam-image" material="side:front" mixin="scale-label" src="/assets/images/talent/SamanthaMathews.jpg"
                position="1.1 -1.08 0" rotation="0 180 0"   geometry="primitive: circle; width: 2; height: 2; depth: 3" scale=".4 .4 .4" width="5" height="5">
            </a-image>



            <a-entity id="hosted" troika-text="value:Hosted by Samantha Mathews
            September 14, 2021
;color:#fff; fontSize:.9;align:left;" material="shader: standard;" position="0 -.4 0"
                rotation="0 180 0" scale=".2 .2 .2" visibility="true"></a-entity>

               


            <a-entity id="biz-details" troika-text="value:A Full-Day of Pioneering Leaders,
on Building the Immersive Web

Starting UTC 15:00
8am PDT | 11am EDT | 17:00 CEST
;color:#fff; fontSize:.6;align:left;" material="shader: standard;" position="-0.32 -1.1 0"
                rotation="0 180 0" scale=".2 .2 .2" visibility="true"></a-entity>

</a-entity>

