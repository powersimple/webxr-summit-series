<footer class="footer">
<div class="container">
<div class="row">

<div id="social-menu" class="col-md-3">
        <ul>
            

        <li><a href="https://twitter.com/webxrawards" target="_blank"
        class="fa fa-x-twitter" title="Follow us on the Social Network formerly known as Twitter"></a>
        </li>
        <li><a href="https://www.instagram.com/webxrawards/" target="_blank" class="fa fa-instagram"
        title="Follow us on Instagram"></a>
        </li>
        <li><a href="https://www.facebook.com/groups/webxrawards" target="_blank" class="fa fa-facebook"
        title="Join our Facebook Group"></a>
        </li>
        <li><a href="https://www.linkedin.com/company/the-polys/" target="_blank" class="fa fa-linkedin"
        title="Connect with us on LinkedIn" target="_blank"></a>
        </li>
        <li><a href="https://discord.gg/T5vRuM5cDS" class="fa discord" target="_blank"
        title="Join our community Discord"></a>
        </li>
        </ul>
</div>

<div id="footer-menu" class="col-md-5"></div>

                <div class="col-md-4" id="rights">

                        <span class="font-alt copyright "><span class="point-cloud">Point Cloud Productions</span><br>
                        <span>&copy; <?=  date("Y")?> Powersimple, LLC -  All Rights Reserved</span></span>
                        </div> 
                </div>
        </div>
</footer>
</div><!-- #flex-wrapper -->


<?php 




wp_footer(); ?>

<script type='text/javascript' src='/wp-content/themes/webxrsummits/main.js?ver=916120' id='main-js'></script>

</body>

</html>