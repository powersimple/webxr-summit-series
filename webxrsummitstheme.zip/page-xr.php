<?php
get_header(); ?>
<div id="globe"></div>
</main>
<?php
get_footer(); 
?>
